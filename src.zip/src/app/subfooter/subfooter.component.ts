import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subfooter',
  templateUrl: './subfooter.component.html',
  styleUrls: ['./subfooter.component.css']
})
export class SubfooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
